
async function sendMessage(){

let input = document.getElementById("input")
let chat = document.getElementById("chat")

let message = input.value

chat.innerHTML += "<p class='user'><b>Tú:</b> "+message+"</p>"

input.value=""

let res = await fetch("https://YOUR-RAILWAY-URL/chat",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({
message:message
})
})

let data = await res.json()

chat.innerHTML += "<p class='bot'><b>Bot:</b> "+data.reply+"</p>"

chat.scrollTop = chat.scrollHeight

}
