
# Chatbot Open Source V1

Stack:
- Netlify (frontend)
- Railway (backend)
- HuggingFace model (Mistral)

## Backend deploy
1. Subir carpeta backend a GitHub
2. Conectar repositorio en Railway
3. Agregar variable:

HF_TOKEN=tu_token_huggingface

## Frontend deploy
1. Subir carpeta frontend a Netlify
2. Editar chat.js y cambiar:

https://YOUR-RAILWAY-URL/chat

por tu URL real.

Listo 🚀
